package com.stit4hlos.app

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private val bg = Color.rgb(13, 12, 19)
    private val panel = Color.rgb(27, 25, 36)
    private val accent = Color.rgb(163, 137, 255)
    private lateinit var body: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility = 0

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(22), dp(20), dp(16))
            setBackgroundColor(bg)
        }
        root.addView(label("STIT4HLOS", 28, Color.WHITE, true))
        root.addView(label("Android test-tool prototype · v0.1.0", 14, 0xFFAAA6B8.toInt()))
        root.addView(space(20))
        val note = label("Standalone UI prototype. Controls are local demo settings; no game memory access or injection is performed.", 14, 0xFFD2CDE3.toInt())
        note.setPadding(dp(14), dp(12), dp(14), dp(12)); note.setBackgroundColor(panel)
        root.addView(note)
        root.addView(space(18))

        val tabs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val scroll = ScrollView(this)
        body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(body)
        val sections = listOf("ESP", "Aim-assist", "X-ray", "Другие")
        sections.forEach { section ->
            val b = Button(this).apply { text = section; setTextColor(Color.WHITE); setBackgroundColor(panel); isAllCaps = false }
            b.setOnClickListener { showSection(section) }
            tabs.addView(b, LinearLayout.LayoutParams(0, dp(48), 1f))
        }
        root.addView(tabs)
        root.addView(space(12))
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        showSection("ESP")
    }

    private fun showSection(section: String) {
        body.removeAllViews()
        body.addView(label(section, 23, Color.WHITE, true))
        body.addView(space(10))
        when (section) {
            "ESP" -> {
                addSwitch("ESP включён (демо)", false)
                addSeek("Максимальная дальность", 100, 500)
                addSwitch("Квадратная рамка", true)
                addSwitch("Показывать подпись", true)
                addSwitch("Показывать расстояние", true)
                addSeek("Размер рамки", 70, 200)
                addColorNote("Цвет метки: фиолетовый (демо)")
            }
            "Aim-assist" -> {
                addSwitch("Aim-assist включён (демо)", false)
                addSeek("Сила наведения", 0, 100)
                addSeek("Радиус захвата", 20, 300)
                addChoice("Точка цели", listOf("Голова", "Тело", "Руки", "Ноги"))
                addColorNote("Настройки пока не воздействуют на игровой клиент.")
            }
            "X-ray" -> {
                addSwitch("X-ray включён (демо)", false)
                listOf("Деревянные стены", "Каменные стены", "Металлические стены", "Металл высокого качества").forEach { addSwitch(it, false) }
                addColorNote("Фильтры типов объектов для будущей тестовой сцены:")
                listOf("Шкафы", "Маленькие ящики", "Большие ящики", "Печки", "Электропечи", "Спальные мешки", "Кровати", "Спящие тестовые персонажи").forEach { addSwitch(it, false) }
            }
            else -> {
                addSwitch("Показывать тестовые объекты", true)
                addSwitch("Локальное журналирование", true)
                addColorNote("Здесь можно разместить настройки интерфейса и отладки.")
            }
        }
    }

    private fun addSwitch(title: String, checked: Boolean) {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(12), dp(5), dp(8), dp(5)); setBackgroundColor(panel) }
        val text = label(title, 15, Color.WHITE)
        row.addView(text, LinearLayout.LayoutParams(0, -2, 1f))
        val sw = Switch(this).apply { isChecked = checked; buttonTintList = android.content.res.ColorStateList.valueOf(accent) }
        row.addView(sw)
        body.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
    }

    private fun addSeek(title: String, initial: Int, max: Int) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(8), dp(12), dp(8)); setBackgroundColor(panel) }
        val value = label("$title: $initial", 15, Color.WHITE)
        val seek = SeekBar(this).apply { this.max = max; progress = initial; progressTintList = android.content.res.ColorStateList.valueOf(accent); thumbTintList = android.content.res.ColorStateList.valueOf(accent) }
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) { value.text = "$title: $p" }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        box.addView(value); box.addView(seek)
        body.addView(box, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
    }

    private fun addChoice(title: String, choices: List<String>) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(8), dp(12), dp(8)); setBackgroundColor(panel) }
        box.addView(label(title, 15, Color.WHITE))
        val spinner = Spinner(this)
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, choices)
        box.addView(spinner)
        body.addView(box, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
    }

    private fun addColorNote(text: String) {
        val v = label(text, 14, accent)
        v.setPadding(dp(12), dp(10), dp(12), dp(10))
        body.addView(v)
    }
    private fun label(text: String, size: Int, color: Int, bold: Boolean = false) = TextView(this).apply {
        this.text = text; textSize = size.toFloat(); setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }
    private fun space(height: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, dp(height)) }
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
}
